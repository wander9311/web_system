#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

if [ -r `dirname $0`/../setting-env.cf ]; then
  . `dirname $0`/../setting-env.cf
fi

echo " ===== start deploy ... ===== "
aws s3 cp s3://${SOURCE_BUCKET_NAME}/${ARCHIVE_NAME} ${TMP_DIR}/${ARCHIVE_NAME}

if [ $? -ne 0 ]; then
  echo 'error: archive file get failed.';
fi

${TOOL_HOME}/bin/local-deploy.sh -f ${TMP_DIR}/${ARCHIVE_NAME}
${TOOL_HOME}/bin/rotate-releases.sh

rm ${TMP_DIR}/${ARCHIVE_NAME}
