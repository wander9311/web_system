#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

my_instance_id=`/usr/bin/curl -s http://169.254.169.254/latest/meta-data/instance-id`
my_server_group=`${TOOL_HOME}/bin/get-tag-value.sh -n "$my_instance_id" -k "SERVER_GROUP"`

if [ -z "$my_server_group" ]; then
  echo "!!! Error. (Maybe EC2 Tag SERVER_GROUP not set.) !!!"
else
  # application settings
  sed -i -e '/SERVER_GROUP/d' ${TOOL_HOME}/setting.cf
  sed -i "1i SERVER_GROUP=$my_server_group" ${TOOL_HOME}/setting.cf
  echo "set server_group application: $my_server_group"
  #zabbix settings
  sudo sed -i -e "s/Hostname=REPLACE_HOSTNAME/Hostname=${my_server_group}_${my_instance_id}/g" /etc/zabbix/zabbix_agentd.conf
  echo "set server_group zabbix: ${my_server_group}_${my_instance_id}"
fi
