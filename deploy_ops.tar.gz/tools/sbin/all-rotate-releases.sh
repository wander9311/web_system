#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

if [ -r `dirname $0`/../setting-stg.cf ]; then
  . `dirname $0`/../setting-stg.cf
fi

echo " ===== start rotating ... ===== "
names=""
if [ ! -z "$TARGET_GROUPS" ]; then
  names=`${TOOL_HOME}/bin/get-names.sh -g "$TARGET_GROUPS"`
fi

if [ ! -z "$TARGET_NAMES" ]; then
  if [ -z "$names" ]; then
    names=$TARGET_NAMES
  else
    names="$names $TARGET_NAMES"
  fi
fi

for name in $names; do
  address=`${TOOL_HOME}/bin/get-address.sh -n $name`

  echo " ***** rotate ${name}(${address}) ***** "
  ssh -l $DEPLOY_USER $address ${TOOL_HOME}/bin/rotate-releases.sh
done

