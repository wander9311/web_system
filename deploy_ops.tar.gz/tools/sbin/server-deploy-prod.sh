#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

echo " ===== start deploy ... ===== "
${TOOL_HOME}/bin/checkout-archive.sh -f ${TMP_DIR}/${ARCHIVE_NAME} -e prod $*

if [ $? -ne 0 ]; then
  echo "error: checkout-archive.sh failed."
  exit 1;
fi

names=""
if [ ! -z "$TARGET_GROUPS" ]; then
  names=`${TOOL_HOME}/bin/get-names.sh -g "$TARGET_GROUPS"`
fi

if [ ! -z "$TARGET_NAMES" ]; then
  if [ -z "$names" ]; then
    names=$TARGET_NAMES
  else
    names="$names $TARGET_NAMES"
  fi
fi

for name in $names; do
  address=`${TOOL_HOME}/bin/get-address.sh -n $name`

  ${TOOL_HOME}/bin/server-upload.sh -f ${TMP_DIR}/${ARCHIVE_NAME} -t $address

  ssh -l $DEPLOY_USER $address ${TOOL_HOME}/bin/local-deploy.sh -f ${TMP_DIR}/${ARCHIVE_NAME}
done

rm ${TMP_DIR}/${ARCHIVE_NAME}
