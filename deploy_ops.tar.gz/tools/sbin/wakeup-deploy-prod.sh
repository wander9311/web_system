#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

echo " ===== start deploy ... ===== "
url=`${TOOL_HOME}/bin/gen-s3-url.php -a ${ACCESS_KEY} -s ${SECRET_KEY} -t /${BUCKET_NAME}/${ARCHIVE_NAME}`

wget $url -O ${TMP_DIR}/${ARCHIVE_NAME}
if [ $? -ne 0 ]; then
  echo 'error: archive file get failed.';
fi

${TOOL_HOME}/bin/local-deploy.sh -f ${TMP_DIR}/${ARCHIVE_NAME}

rm ${TMP_DIR}/${ARCHIVE_NAME}
