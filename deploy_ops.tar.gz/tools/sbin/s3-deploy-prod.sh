#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

echo " ===== start deploy ... ===== "
${TOOL_HOME}/bin/checkout-archive.sh -f ${TMP_DIR}/${ARCHIVE_NAME} -e prod $*

if [ $? -ne 0 ]; then
  echo "error: checkout-archive.sh failed."
  exit 1;
fi

${TOOL_HOME}/bin/s3-upload.sh -f ${TMP_DIR}/${ARCHIVE_NAME} -t ${BUCKET_NAME}

rm ${TMP_DIR}/${ARCHIVE_NAME}
