#!/bin/bash

if [ -r `dirname $0`/../setting.cf ]; then
  . `dirname $0`/../setting.cf
fi

echo " ===== start sync files ... ===== "
names=""
if [ ! -z "$TARGET_GROUPS" ]; then
  names=`${TOOL_HOME}/bin/get-names.sh -g "$TARGET_GROUPS"`
fi

if [ ! -z "$TARGET_NAMES" ]; then
  if [ -z "$names" ]; then
    names=$TARGET_NAMES
  else
    names="$names $TARGET_NAMES"
  fi
fi

if [ ! -r ${TOOL_HOME}/sync-files ]; then
  echo "${TOOL_HOME}/sync-files not found."
  exit 1;
fi

files=`cat ${TOOL_HOME}/sync-files`

for name in $names; do
  address=`${TOOL_HOME}/bin/get-address.sh -n $name`

  for file in $files; do
    if [ -d ${TOOL_HOME}/sync-data/prod/web/$file ]; then
      echo "cannot sync deirectory. [${TOOL_HOME}/sync-data/prod/web/$file]"
    elif [ -f ${TOOL_HOME}/sync-data/prod/web/$file ]; then
      scp -p ${TOOL_HOME}/sync-data/prod/web/$file ${DEPLOY_USER}@$address:${DEPLOY_PATH}/web/$file
    else
      echo "cannot read file. [${TOOL_HOME}/sync-data/prod/web/$file]"
    fi
  done
done
